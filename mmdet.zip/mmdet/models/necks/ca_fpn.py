from mmdet.models.necks import FPN
from .ca_attention import CoordAtt

from ..builder import NECKS
@NECKS.register_module()
class FPNWithCoordAtt(FPN):
    def __init__(self,
                in_channels,
                out_channels,
                num_outs,
                start_level=0,
                end_level=-1,
                add_extra_convs=False,
                extra_convs_on_inputs=True,
                relu_before_extra_convs=False,
                no_norm_on_lateral=False,
                conv_cfg=None,
                norm_cfg=None,
                act_cfg=None,
                reduction=16,
                upsample_cfg=dict(mode='nearest')):
        super(FPNWithCoordAtt, self).__init__(
            in_channels=in_channels,
            out_channels=out_channels,
            num_outs=num_outs,
            start_level=start_level,
            end_level=end_level,
            add_extra_convs=add_extra_convs,
            relu_before_extra_convs=relu_before_extra_convs,
            no_norm_on_lateral=no_norm_on_lateral,
            conv_cfg=conv_cfg,
            norm_cfg=norm_cfg,
            act_cfg=act_cfg,
            upsample_cfg=upsample_cfg)
        self.ca_attention = CoordAtt(out_channels,reduction)
 
    def forward(self, inputs):
        outs = super(FPNWithCoordAtt, self).forward(inputs)
        # Apply CA attention to the last three outputs
        if len(outs) >= 3:
            outs[-3:] = [self.ca_attention(out) for out in outs[-3:]]
        # If there are fewer than three outputs, do nothing (or handle the case as needed)
        return tuple(outs)