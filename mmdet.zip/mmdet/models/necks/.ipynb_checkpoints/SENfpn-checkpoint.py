import torch.nn as nn
import torch.nn.functional as F
from mmcv.cnn import ConvModule
from mmcv.runner import BaseModule, auto_fp16

from ..builder import NECKS


@NECKS.register_module()
class SENFPN(BaseModule):
    def __init__(self,
                 in_channels,
                 out_channels,
                 num_outs,
                 start_level=0,
                 end_level=-1,
                 add_extra_convs=False,
                 relu_before_extra_convs=False,
                 no_norm_on_lateral=False,
                 conv_cfg=None,
                 norm_cfg=None,
                 act_cfg=None,
                 upsample_cfg=dict(mode='nearest'),
                 fusion_mode='add',  # 可以是 'add', 'concat', 或 'select'
                 init_cfg=dict(
                     type='Xavier', layer='Conv2d', distribution='uniform')):
        super(SENFPN, self).__init__(init_cfg)
        assert isinstance(in_channels, list)
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.num_ins = len(in_channels)
        self.num_outs = num_outs
        self.relu_before_extra_convs = relu_before_extra_convs
        self.no_norm_on_lateral = no_norm_on_lateral
        self.fp16_enabled = False
        self.upsample_cfg = upsample_cfg.copy()
        self.fusion_mode = fusion_mode  # 融合模式

        if end_level == -1 or end_level == self.num_ins - 1:
            self.backbone_end_level = self.num_ins
            assert num_outs >= self.num_ins - start_level
        else:
            self.backbone_end_level = end_level + 1
            assert end_level < self.num_ins
            assert num_outs == end_level - start_level + 1
        self.start_level = start_level
        self.end_level = end_level
        self.add_extra_convs = add_extra_convs
        assert isinstance(add_extra_convs, (str, bool))
        if isinstance(add_extra_convs, str):
            assert add_extra_convs in ('on_input', 'on_lateral', 'on_output')
        elif add_extra_convs:
            self.add_extra_convs = 'on_input'

        self.lateral_convs = nn.ModuleList()
        self.fpn_convs = nn.ModuleList()
       
        
        for i in range(self.start_level, self.backbone_end_level):
            l_conv = ConvModule(
                in_channels[i],
                out_channels,
                1,
                conv_cfg=conv_cfg,
                norm_cfg=norm_cfg if not self.no_norm_on_lateral else None,
                act_cfg=act_cfg,
                inplace=False)
            fpn_conv = ConvModule(
                out_channels,
                out_channels,
                3,
                padding=1,
                conv_cfg=conv_cfg,
                norm_cfg=norm_cfg,
                act_cfg=act_cfg,
                inplace=False)

            self.lateral_convs.append(l_conv)
            self.fpn_convs.append(fpn_conv)


        # 添加特征融合卷积层
        self.fusion_conv_d3 = ConvModule(
            out_channels,
            out_channels,
            3,
            padding=1,
            conv_cfg=conv_cfg,
            norm_cfg=norm_cfg,
            act_cfg=act_cfg,
            inplace=False)
        self.fusion_conv_d4 = ConvModule(
            out_channels,
            out_channels,
            3,
            padding=1,
            conv_cfg=conv_cfg,
            norm_cfg=norm_cfg,
            act_cfg=act_cfg,
            inplace=False)

        # 添加融合后的特征与原始特征的融合或选择模块
        if self.fusion_mode == 'concat':
            self.fusion_concat_conv_d3 = ConvModule(
                out_channels * 2,
                out_channels,
                1,
                conv_cfg=conv_cfg,
                norm_cfg=norm_cfg,
                act_cfg=act_cfg,
                inplace=False)
            self.fusion_concat_conv_d4 = ConvModule(
                out_channels * 2,
                out_channels,
                1,
                conv_cfg=conv_cfg,
                norm_cfg=norm_cfg,
                act_cfg=act_cfg,
                inplace=False)
        elif self.fusion_mode == 'select':
            # 可以添加一个轻量级模块（如1x1卷积）来学习选择权重
            self.fusion_select_conv_d3 = ConvModule(
                out_channels * 2,
                1,
                1,
                conv_cfg=conv_cfg,
                norm_cfg=None,
                act_cfg=None,
                inplace=False)
            self.fusion_select_conv_d4 = ConvModule(
                out_channels * 2,
                1,
                1,
                conv_cfg=conv_cfg,
                norm_cfg=None,
                act_cfg=None,
                inplace=False)

        # 添加额外卷积层（若有）
        extra_levels = num_outs - self.backbone_end_level + self.start_level
        if self.add_extra_convs and extra_levels >= 1:
            for i in range(extra_levels):
                if i == 0 and self.add_extra_convs == 'on_input':
                    in_channels = self.in_channels[self.backbone_end_level - 1]
                else:
                    in_channels = out_channels
                extra_fpn_conv = ConvModule(
                    in_channels,
                    out_channels,
                    3,
                    stride=2,
                    padding=1,
                    conv_cfg=conv_cfg,
                    norm_cfg=norm_cfg,
                    act_cfg=act_cfg,
                    inplace=False)
                self.fpn_convs.append(extra_fpn_conv)


    @auto_fp16()
    def forward(self, inputs):
        assert len(inputs) == len(self.in_channels)

        # 构建横向连接
        laterals = [
            lateral_conv(inputs[i + self.start_level])
            for i, lateral_conv in enumerate(self.lateral_convs)
        ]

        # build top-down path
        used_backbone_levels = len(laterals)
        for i in range(used_backbone_levels - 1, 0, -1):
            if 'scale_factor' in self.upsample_cfg:
                upsampled = F.interpolate(laterals[i], **self.upsample_cfg)
                laterals[i - 1] = laterals[i - 1] + upsampled
            else:
                prev_shape = laterals[i - 1].shape[2:]
                upsampled = F.interpolate(laterals[i], size=prev_shape, **self.upsample_cfg)
                laterals[i - 1] = laterals[i - 1] + upsampled

        # 保存原始FPN路径产生的特征（P3, P4）
        original_p3 = laterals[1]  # 假设P3对应索引1
        original_p4 = laterals[2]  # 假设P4对应索引2

        # 跨尺度特征融合（d3和d5）
        if used_backbone_levels >= 4:
            d3_feat = inputs[self.start_level + 1]  # 假设D3对应索引1
            # 直接使用骨干网络的C5特征作为d5_feat
            d5_feat = inputs[self.start_level + 3] if len(inputs) > self.start_level + 3 else inputs[-1]
            d5_up = F.interpolate(d5_feat, size=d3_feat.shape[2:], **self.upsample_cfg)
            fused_d3 = d3_feat + d5_up
            fused_d3 = self.fusion_conv_d3(fused_d3)

            d4_feat = inputs[self.start_level + 2]  # 假设D4对应索引2
            d5_up_d4 = F.interpolate(d5_feat, size=d4_feat.shape[2:], **self.upsample_cfg)
            fused_d4 = d4_feat + d5_up_d4
            fused_d4 = self.fusion_conv_d4(fused_d4)

   
        outs = []
        for i in range(used_backbone_levels):
            # 先应用常规FPN卷积
            fpn_out = self.fpn_convs[i](laterals[i])

            outs.append(fpn_out)

        # 融合或选择融合后的特征与原始特征
        if used_backbone_levels >= 4:
            # 融合D3'与P3
            if self.fusion_mode == 'add':
                fused_p3 = original_p3 + fused_d3
            elif self.fusion_mode == 'concat':
                fused_p3 = torch.cat([original_p3, fused_d3], dim=1)
                fused_p3 = self.fusion_concat_conv_d3(fused_p3)
            elif self.fusion_mode == 'select':
                combined = torch.cat([original_p3, fused_d3], dim=1)
                weights = torch.sigmoid(self.fusion_select_conv_d3(combined))
                fused_p3 = weights * original_p3 + (1 - weights) * fused_d3
            else:
                raise ValueError(f'Unknown fusion mode: {self.fusion_mode}')

            # 融合D4'与P4
            if self.fusion_mode == 'add':
                fused_p4 = original_p4 + fused_d4
            elif self.fusion_mode == 'concat':
                fused_p4 = torch.cat([original_p4, fused_d4], dim=1)
                fused_p4 = self.fusion_concat_conv_d4(fused_p4)
            elif self.fusion_mode == 'select':
                combined = torch.cat([original_p4, fused_d4], dim=1)
                weights = torch.sigmoid(self.fusion_select_conv_d4(combined))
                fused_p4 = weights * original_p4 + (1 - weights) * fused_d4
            else:
                raise ValueError(f'Unknown fusion mode: {self.fusion_mode}')

            fused_p3 = self.fpn_convs[1](fused_p3)
 
            outs[1] = fused_p3

            fused_p4 = self.fpn_convs[2](fused_p4)
 
            outs[2] = fused_p4

        # 添加额外层级
        if self.num_outs > len(outs):
            if not self.add_extra_convs:
                for i in range(self.num_outs - used_backbone_levels):
                    outs.append(F.max_pool2d(outs[-1], 1, stride=2))
            else:
                if self.add_extra_convs == 'on_input':
                    extra_source = inputs[self.backbone_end_level - 1]
                elif self.add_extra_convs == 'on_lateral':
                    extra_source = laterals[-1]
                else:
                    extra_source = outs[-1]
                
                # 处理额外层级
                for i in range(used_backbone_levels, self.num_outs):
                    if i < len(self.fpn_convs):
                        if self.relu_before_extra_convs:
                            extra_feat = F.relu(extra_source)
                        else:
                            extra_feat = extra_source
                        extra_out = self.fpn_convs[i](extra_feat)
                        outs.append(extra_out)
                    else:
                        # 如果fpn_convs不够，使用max pooling
                        outs.append(F.max_pool2d(outs[-1], 1, stride=2))
                    
                    if i < len(self.fpn_convs) - 1:
                        if self.relu_before_extra_convs:
                            extra_source = F.relu(outs[-1])
                        else:
                            extra_source = outs[-1]
                        if 'scale_factor' in self.upsample_cfg:
                            extra_source = F.interpolate(extra_source, scale_factor=0.5, **self.upsample_cfg)
                        else:
                            extra_source = F.interpolate(extra_source, size=(outs[-1].shape[2]//2, outs[-1].shape[3]//2), **self.upsample_cfg)

        return tuple(outs)
