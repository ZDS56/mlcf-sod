from mmdet.models.necks import FPN
from .contextaggregation import ContextAggregation

from ..builder import NECKS
@NECKS.register_module()
class FPNWithContextAgg(FPN):
    def __init__(self,
                in_channels,
                out_channels,
                num_outs,
                start_level=0,
                end_level=-1,
                add_extra_convs=False,
                extra_convs_on_inputs=True,
                relu_before_extra_convs=False,
                no_norm_on_lateral=False,
                conv_cfg=None,
                norm_cfg=None,
                act_cfg=None,
                reduction=16,
                upsample_cfg=dict(mode='nearest')):
        super(FPNWithContextAgg, self).__init__(
            in_channels=in_channels,
            out_channels=out_channels,
            num_outs=num_outs,
            start_level=start_level,
            end_level=end_level,
            add_extra_convs=add_extra_convs,
            relu_before_extra_convs=relu_before_extra_convs,
            no_norm_on_lateral=no_norm_on_lateral,
            conv_cfg=conv_cfg,
            norm_cfg=norm_cfg,
            act_cfg=act_cfg,
            upsample_cfg=upsample_cfg)
        self.contextaggregation = ContextAggregation(out_channels,reduction)

    def forward(self, inputs):
        outs = super(FPNWithContextAgg, self).forward(inputs)
        # 将元组转换为列表
        outs_list = list(outs)
        # 应用CA注意力到最后的三个输出（如果存在的话）
        if len(outs_list) >= 3:
            outs_list[-3:] = [self.contextaggregation(out) for out in outs_list[-3:]]
        # 将列表转换回元组（如果需要的话）
        # outs = tuple(outs_list)  # 如果你需要返回元组的话，取消注释这一行
        # 否则，你可以直接返回列表，这取决于你的下游代码是否需要元组
        return tuple(outs_list)  # 或者返回 tuple(outs_list)