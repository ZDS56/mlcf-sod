from mmengine.model import BaseModule

import torch.nn as nn
class SEAttention(BaseModule):
    def __init__(self,
                 channels,
                 reduction=16,
                 init_cfg=None,#init_cfg: 这是一个可选参数，用于指定初始化配置。
                 **kwargs):#允许传递额外的参数给初始化方法。
        super(SEAttention, self).__init__(init_cfg=init_cfg)
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channels, channels // reduction, False),
            nn.ReLU(inplace=True),
            nn.Linear(channels // reduction, channels, False),
            nn.Sigmoid()
        )
 
    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y.expand_as(x)
