import torch
import torch.nn as nn
import torch.nn.functional as F
from mmcv.cnn import ConvModule
from mmcv.runner import BaseModule, auto_fp16
from ..builder import NECKS

from .cdfa import CDFA
@NECKS.register_module()
class CDFAEnhancedFPN(BaseModule):

    def __init__(self,
                 in_channels,
                 out_channels,
                 num_outs,
                 start_level=0,
                 end_level=-1,
                 add_extra_convs=False,
                 cdfa_num_heads=8,  # 新增CDFA参数
                 cdfa_kernel_size=3,
                 conv_cfg=None,
                 norm_cfg=None,
                 act_cfg=None,
                 upsample_cfg=dict(mode='nearest'),
                 init_cfg=dict(type='Xavier', distribution='uniform')):
        super().__init__(init_cfg)
        
        # 原始FPN参数初始化
        assert isinstance(in_channels, list)
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.num_ins = len(in_channels)
        self.num_outs = num_outs
        self.upsample_cfg = upsample_cfg.copy()
        
        # 层级配置
        if end_level == -1:
            self.backbone_end_level = self.num_ins - 1
        else:
            self.backbone_end_level = end_level
        self.start_level = start_level
        self.add_extra_convs = add_extra_convs

        # 横向连接层
        self.lateral_convs = nn.ModuleList()
        for i in range(self.start_level, self.backbone_end_level + 1):
            l_conv = ConvModule(
                in_channels[i],
                out_channels,
                1,
                conv_cfg=conv_cfg,
                norm_cfg=norm_cfg,
                act_cfg=act_cfg)
            self.lateral_convs.append(l_conv)

        # 添加CDFA模块
        self.cdfa_layers = nn.ModuleList([
            CDFA(
                in_c=out_channels,
                dim=out_channels,
                num_heads=cdfa_num_heads,
                kernel_size=cdfa_kernel_size
            ) for _ in range(self.backbone_end_level - self.start_level)
        ])

        # 特征金字塔卷积
        self.fpn_convs = nn.ModuleList()
        for _ in range(self.backbone_end_level - self.start_level + 1):
            fpn_conv = ConvModule(
                out_channels,
                out_channels,
                3,
                padding=1,
                conv_cfg=conv_cfg,
                norm_cfg=norm_cfg,
                act_cfg=act_cfg)
            self.fpn_convs.append(fpn_conv)

        # 额外卷积层
        if add_extra_convs:
            self.extra_convs = nn.ModuleList()
            for i in range(num_outs - (self.backbone_end_level - self.start_level + 1)):
                extra_conv = ConvModule(
                    out_channels,
                    out_channels,
                    3,
                    stride=2,
                    padding=1,
                    conv_cfg=conv_cfg,
                    norm_cfg=norm_cfg)
                self.extra_convs.append(extra_conv)

    @auto_fp16()
    def forward(self, inputs):
        # 验证输入特征图数量
        assert len(inputs) == len(self.in_channels)

        # 构建横向连接特征
        laterals = [
            lateral_conv(inputs[i + self.start_level])
            for i, lateral_conv in enumerate(self.lateral_convs)
        ]

        # 自顶向下路径构建
        for i in range(len(laterals)-1, 0, -1):
            prev_shape = laterals[i-1].shape[2:]
            laterals[i-1] += F.interpolate(
                laterals[i], size=prev_shape, **self.upsample_cfg)

        # CDFA特征增强
        enhanced_features = []
        for i, (lat, cdfa) in enumerate(zip(laterals, self.cdfa_layers)):
            # 获取相邻层特征作为上下文
            if i == 0:
                fg_feat = laterals[i+1]
                bg_feat = torch.zeros_like(lat)  # 最低层无背景特征
            elif i == len(laterals)-1:
                bg_feat = laterals[i-1]
                fg_feat = torch.zeros_like(lat)  # 最高层无前景特征
            else:
                fg_feat = laterals[i+1]
                bg_feat = laterals[i-1]
            
            # 应用CDFA模块
            enhanced = cdfa(lat, fg_feat, bg_feat)
            enhanced_features.append(enhanced)

        # 构建输出特征金字塔
        outs = [self.fpn_convs[i](feat) for i, feat in enumerate(enhanced_features)]

        # 添加额外层级
        if self.add_extra_convs and hasattr(self, 'extra_convs'):
            for i, extra_conv in enumerate(self.extra_convs):
                if i == 0:
                    feat = outs[-1]
                else:
                    feat = outs[-1]
                feat = extra_conv(feat)
                outs.append(feat)

        return tuple(outs)