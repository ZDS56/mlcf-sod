from mmengine.model import BaseModule
import torch
import torch.nn as nn
 
class EfficientLocalizationAttention(BaseModule):
    def __init__(self, channel,reduction=8, kernel_size=5):
        super(EfficientLocalizationAttention, self).__init__()
        self.pad = kernel_size // 2
        self.conv = nn.Conv1d(channel, channel, kernel_size=kernel_size, padding=self.pad, groups=channel // reduction, bias=False)
        self.gn = nn.GroupNorm(16, channel)
        self.sigmoid = nn.Sigmoid()
 
    def forward(self, x):
        b, c, h, w = x.size()
 
        # 处理高度维度
        x_h = torch.mean(x, dim=3, keepdim=True).view(b, c, h)
        x_h = self.sigmoid(self.gn(self.conv(x_h))).view(b, c, h, 1)
 
        # 处理宽度维度
        x_w = torch.mean(x, dim=2, keepdim=True).view(b, c, w)
        x_w = self.sigmoid(self.gn(self.conv(x_w))).view(b, c, 1, w)
 
     
        # 在两个维度上应用注意力
        return x * x_h * x_w

 
"""
为了在考虑参数数量的同时优化ELA的性能，作者引入了四种方案: ELA-Tiny(ELA-T)，ELABase(ELA-B)，ELA-Smal(ELA-S)和ELA-Large(ELA-L)。
1.ELA-T的参数配置定义为 kernel size=5,groups =in channels， num group=32:
2.ELA-B的参数配置定义为 kernel size=7，groups =in_channels， num_group =16:
3.ELA-S的参数配置为 kernel size=5,groups=in_channels/8, num_group=16。
4.ELA-L的参数配置为 kernel_size=7,groups=in _channels /8，num_group=16 。
"""